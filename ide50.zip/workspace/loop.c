#include <stdio.h>

int main(void)

while(true);
{
    printf("Hello world");
}